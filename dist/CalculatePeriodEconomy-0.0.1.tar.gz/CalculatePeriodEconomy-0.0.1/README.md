# Calculate_Period_Economy Library

สวัสดีครับ ไลบรารี่นี้ใช้สำหรับงาน Economy ความสามารถคือใช้ในการคำนวณ

1.คำนวณดอกเบี้ย
2.คำนวณจุดคุ้มทุน
3.คำนวณและเปรียบเทียบอุณกรณ์ต่างๆ


### วิธีติดตั้งแสนง่าย

เราจะติดตั้งผ่านเจ้า pip

```sh
pip install Calculate_Period_Economy
```
- เปิด Python แล้วพิพม์ตามนี้เลย
```sh
from Calculate import CalculatePeriodEconomy

CPE = CalculatePeriodEconomy()
print(CPE.help())
```

### Visit

| สร้างไฟล์ README  | https://dillinger.io/ |

### สามารถติดตามผลงานได้...https://github.com/tooe81948
